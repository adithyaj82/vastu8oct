//
//  VastuViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/2/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class VastuViewController: UIViewController {
    @IBOutlet weak var myWebView: UIWebView!
    @IBOutlet weak var menuButton: UIBarButtonItem!

    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
//        let url = URL(string: "http://www.ashwintrivedi.com/vastushastra.html")
//        myWebView.loadRequest(URLRequest(url: url!))
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
    @IBAction func web(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        customizeNavBar()
        sideMenus()
        let url = URL(string: "http://www.ashwintrivedi.com/vastushastra.html")
        myWebView.loadRequest(URLRequest(url: url!))

    }
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 252/255, green: 102/255, blue: 45/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }

}
